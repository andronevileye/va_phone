package ru.evileye.voicecontrol

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val button = Button(this).apply {
            text = "🎤 Говорить"
            textSize = 24f
            setOnClickListener { listen() }
        }
        status = TextView(this).apply {
            textSize = 17f
            setPadding(0, 48, 0, 0)
            text = HELP
        }
        layout.addView(button)
        layout.addView(status)
        setContentView(layout)

        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }

    private fun show(s: String) {
        runOnUiThread { status.text = s }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ---------- Распознавание речи ----------

    private fun listen() {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            show("Нужно разрешение на микрофон")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("Распознавание речи недоступно на этом телефоне")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { show("Слушаю…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { show("Не расслышал, попробуй ещё раз (код $error)") }
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (text == null) {
                    show("Ничего не распознано")
                } else {
                    show("Распознано: $text")
                    handle(text)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        }
        r.startListening(intent)
    }

    // ---------- Разбор команд ----------

    private fun handle(raw: String) {
        val t = raw.lowercase().trim()
        when {
            t.contains("ютуб") || t.contains("youtube") -> youtube(t)
            t.startsWith("напиши") || t.startsWith("отправь сообщение") -> message(t)
            t.startsWith("позвони") || t.startsWith("набери") -> call(t)
            else -> show("Не понял команду: $raw\n\n$HELP")
        }
    }

    /** Возвращает (приложение: "wa" / "tg" / null, слова команды без названия приложения). */
    private fun parse(t: String): Pair<String?, List<String>> {
        val words = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        var app: String? = null
        val out = mutableListOf<String>()
        for (w in words) {
            val a = when {
                w.startsWith("ватсап") || w.startsWith("вотсап") ||
                    w.startsWith("вацап") || w.startsWith("whatsapp") -> "wa"
                w.startsWith("телеграм") || w.startsWith("telegram") -> "tg"
                else -> null
            }
            if (a != null) {
                app = a
                if (out.isNotEmpty() && (out.last() == "в" || out.last() == "по")) {
                    out.removeAt(out.size - 1)
                }
            } else {
                out.add(w)
            }
        }
        return Pair(app, out)
    }

    // ---------- YouTube ----------

    private fun youtube(t: String) {
        val url = if (t.contains("найди")) {
            val q = t.substringAfter("найди")
                .replace(Regex("(на|в)\\s+(ютубе|ютуб|youtube)"), "")
                .trim()
            "https://www.youtube.com/results?search_query=" + Uri.encode(q)
        } else {
            "https://www.youtube.com"
        }
        open(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    // ---------- Звонки ----------

    private fun call(t: String) {
        val (app, words) = parse(t)
        val target = words.drop(1).joinToString(" ")
        val number = resolveNumber(target) ?: run {
            show("Не нашёл номер или контакт: $target")
            return
        }
        when (app) {
            "wa" -> open(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + intl(number))))
            "tg" -> open(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=" + intl(number))))
            else -> {
                val action = if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
                open(Intent(action, Uri.parse("tel:" + Uri.encode(number))))
            }
        }
    }

    // ---------- Сообщения ----------

    private fun message(t: String) {
        val (app, words) = parse(t)
        val rest = words.dropWhile { it == "напиши" || it == "отправь" || it == "сообщение" }
        val i = rest.indexOfFirst { it == "текст" || it == "что" }
        if (i < 0) {
            show("Скажи так: напиши в ватсап <имя> текст <сообщение>")
            return
        }
        val target = rest.take(i).joinToString(" ")
        val text = rest.drop(i + 1).joinToString(" ")
        val number = resolveNumber(target) ?: run {
            show("Не нашёл номер или контакт: $target")
            return
        }
        when (app) {
            "wa" -> open(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/" + intl(number) + "?text=" + Uri.encode(text))
                )
            )
            "tg" -> {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("msg", text))
                Toast.makeText(this, "Текст скопирован — вставь в чат", Toast.LENGTH_LONG).show()
                open(Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=" + intl(number))))
            }
            else -> open(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
                    .putExtra("sms_body", text)
            )
        }
    }

    // ---------- Контакты и номера ----------

    private fun resolveNumber(target: String): String? {
        if (target.isBlank()) return null
        val onlyDigits = target.none { it.isLetter() } && target.count { it.isDigit() } >= 5
        if (onlyDigits) return target.filter { it.isDigit() || it == '+' }
        return findContact(target)
    }

    private fun findContact(name: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) {
            show("Нет доступа к контактам")
            return null
        }
        // «маме» / «Ивану» -> ищем по основе слова
        val stem = if (name.length > 4) name.dropLast(2) else name
        contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0)?.lowercase() ?: continue
                if (n.contains(stem)) return c.getString(1)
            }
        }
        return null
    }

    private fun intl(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("8")) d = "7" + d.substring(1)
        return d
    }

    private fun open(i: Intent) {
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            show("Не нашёл приложение для этого действия")
        } catch (e: SecurityException) {
            show("Нет разрешения на это действие")
        }
    }

    companion object {
        const val HELP = "Примеры команд:\n" +
            "• позвони Ивану\n" +
            "• позвони 8 916 123 45 67\n" +
            "• позвони в ватсап Ивану\n" +
            "• позвони в телеграм Ивану\n" +
            "• напиши в ватсап Ивану текст привет, как дела\n" +
            "• напиши Ивану текст буду через час (SMS)\n" +
            "• открой ютуб\n" +
            "• найди на ютубе котики"
    }
}
